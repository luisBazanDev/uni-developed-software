package pe.edu.utp.s02;

import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        double price, distance;
        String from, to;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Desde donde vas a comprar el boleto?");
        from = scanner.nextLine();

        System.out.println("Cual es el destino?");
        to = scanner.nextLine();

        System.out.println("Cual es el valor del boleto? (USD)");
//        price = scanner.nextDouble();
        price = scanner.nextInt();

        System.out.println("Cual es la distancia del viaje? (Km)");
        distance = scanner.nextDouble();

        System.out.println("#################################################");
        System.out.println("          Boleto de viaje - Cix Airline          ");
        System.out.printf("     Desde %s hasta %s", from, to);
        System.out.println();
        System.out.printf("%.2f$                             %.2fKm", price, distance);
        System.out.println();
        System.out.println("#################################################");
    }
}
