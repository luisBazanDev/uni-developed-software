package pe.edu.utp.s02;
import java.util.Scanner;

public class Ejercicios3 {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        int numCuenta;
        double montOp;
        int edad;
        String name, tipoOp;

        System.out.println("Indique la edad del cliente");
        edad = lector.nextInt();

        if (edad < 18) {
            System.out.println("Operación bancaria denegada");
            return;
        }

        System.out.println("Acceso permitido");
        System.out.print("Ingrese el nombre del cliente: ");
        lector.nextLine();
        name = lector.nextLine();
        System.out.print("Ingrese el número de cuenta: ");
        numCuenta = lector.nextInt();
        System.out.print("Ingrese el tipo de operación: ");
        lector.nextLine();
        tipoOp = lector.nextLine();
        System.out.print("Ingrese el monto de la operación: ");
        montOp = lector.nextDouble();

        System.out.println("\n################ TIENDA LUCHITO ################");
        System.out.println("Nombre del cliente: " + name);
        System.out.println("Número de cuenta: " + numCuenta);
        System.out.println("Tipo de operación: " + tipoOp);
        System.out.println("Monto de la operación: S/" + montOp);
        System.out.println("################################################");

    }
}
