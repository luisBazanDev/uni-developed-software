package pe.edu.utp.s02;

import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        double total, subtotal, desc;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el precio del producto:");
//        subtotal = scanner.nextDouble();
        subtotal = scanner.nextByte();

        System.out.println("Ingrese el descuento del producto:");
        desc = scanner.nextDouble();

        total = subtotal - desc;

        System.out.println("##########################");
        System.out.println("        TIENDA ABC");
        System.out.println("##########################");
        System.out.println();
        System.out.printf("SubTotal:      s/%.2f", subtotal);
        System.out.println();
        System.out.printf("Descuento:     s/%.2f", desc);
        System.out.println();
        System.out.printf("Total:         s/%.2f", total);
        System.out.println();
        System.out.println();
        System.out.println("##########################");
        System.out.println("VUELVE PRONTO!");
        System.out.println("##########################");
    }
}
