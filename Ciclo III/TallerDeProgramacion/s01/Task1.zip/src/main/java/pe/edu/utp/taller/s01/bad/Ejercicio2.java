package pe.edu.utp.taller.s01.bad;

public class Ejercicio2 {
    // Formula matematica que utilice 3 variables con error
    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 23;
        int num3 = 34;

        float total = (float) (num1 + num2) * num3 / num1;
        System.out.printf("(%d + %f) * %d / %d = %f", num1, num2, num3, num1, total);
    }
}
