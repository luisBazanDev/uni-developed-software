package pe.edu.utp.taller.s01.good;

public class Ejercicio1 {
    // Area del triangulo
    public static void main(String[] args) {
        float height = 7;
        float base = 3;

        float area = base * height / 2;

        System.out.printf("El area del triangulo es: %f", area);
    }
}
