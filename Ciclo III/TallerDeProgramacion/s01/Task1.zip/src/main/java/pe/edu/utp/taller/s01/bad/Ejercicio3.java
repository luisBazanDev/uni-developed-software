package pe.edu.utp.taller.s01.bad;

public class Ejercicio3 {
    // Descomponer en monto total y igv con error
    public static void main(String[] args) {
        float price = 100;
        float igv = price * 18 / 100;
        float total = price + igv;

        System.out.printf("Precio:         s/%f", price);
        System.out.println();
        System.out.printf("IGV:            s/%f", igv);
        System.out.println();
        System.out.printf("Total a pagar:  s/%d", total);
    }
}
