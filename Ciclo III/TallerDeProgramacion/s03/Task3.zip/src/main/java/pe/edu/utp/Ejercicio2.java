package pe.edu.utp;

public class Ejercicio2 {
}
